import { Component } from '@angular/core';

@Component({
  selector: 'app-generic-error',
  imports: [],
  template: `
    <p>
      generic-error works!
    </p>
  `,
  styles: ``
})
export class GenericError {

}

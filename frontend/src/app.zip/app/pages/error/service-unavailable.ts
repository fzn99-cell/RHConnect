import { Component } from '@angular/core';

@Component({
  selector: 'app-service-unavailable',
  imports: [],
  template: `
    <p>
      service-unavailable works!
    </p>
  `,
  styles: ``
})
export class ServiceUnavailable {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-bad-request',
  imports: [],
  template: `
    <p>
      bad-request works!
    </p>
  `,
  styles: ``
})
export class BadRequest {

}

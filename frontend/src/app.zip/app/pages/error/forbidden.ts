import { Component } from '@angular/core';

@Component({
  selector: 'app-forbidden',
  imports: [],
  template: `
    <p>
      forbidden works!
    </p>
  `,
  styles: ``
})
export class Forbidden {

}

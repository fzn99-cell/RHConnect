import { Component } from '@angular/core';

@Component({
  selector: 'app-internal-server-error',
  imports: [],
  template: `
    <p>
      internal-server-error works!
    </p>
  `,
  styles: ``
})
export class InternalServerError {

}

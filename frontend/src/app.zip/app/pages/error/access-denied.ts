import { Component } from '@angular/core';

@Component({
  selector: 'app-access-denied',
  imports: [],
  template: `
    <p>
      access-denied works!
    </p>
  `,
  styles: ``
})
export class AccessDenied {

}

import { Component } from '@angular/core';

@Component({
  selector: 'app-gateway-timeout',
  imports: [],
  template: `
    <p>
      gateway-timeout works!
    </p>
  `,
  styles: ``
})
export class GatewayTimeout {

}
